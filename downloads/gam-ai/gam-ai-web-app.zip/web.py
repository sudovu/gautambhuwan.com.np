"""Zero-Dependency Embedded Web Server & REST API with Live Model Downloader & PWA."""

import http.server
import json
import urllib.parse
import urllib.request
import os
import threading
import time
import sys
from typing import Optional, Any, Dict
from gam_ai.core.chat.engine import ChatEngine
from gam_ai.core.network.subnet import SubnetCalculator
from gam_ai.core.network.multivendor import MultiVendorConfigGenerator
from gam_ai.core.models.manager import MODULAR_CATALOG
from gam_ai.core.multimodal.generator import MultimodalGenerator

multimodal_generator = MultimodalGenerator()


def get_ui_dir() -> str:
    """Resolve directory containing web UI assets (dashboard.html, manifest, etc.), supporting PyInstaller bundles."""
    if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
        bundle_path = os.path.join(sys._MEIPASS, "gam_ai", "ui")
        if os.path.exists(bundle_path):
            return bundle_path
        return getattr(sys, '_MEIPASS')
    return os.path.dirname(__file__)

_HTML_PATH = os.path.join(get_ui_dir(), "dashboard.html")

DOWNLOAD_STATUS: Dict[str, Dict[str, Any]] = {}

def _download_worker(model_id: str, url: str, dest_path: str, size_mb: int):
    DOWNLOAD_STATUS[model_id] = {
        "status": "downloading",
        "percent": 0.0,
        "downloaded_mb": 0.0,
        "total_mb": size_mb,
        "error": None
    }

    def _hook(blocks, block_size, total_size):
        bytes_down = blocks * block_size
        tot = total_size if total_size > 0 else (size_mb * 1024 * 1024)
        pct = min(100.0, round((bytes_down / tot) * 100.0, 1))
        DOWNLOAD_STATUS[model_id]["percent"] = pct
        DOWNLOAD_STATUS[model_id]["downloaded_mb"] = round(bytes_down / (1024 * 1024), 1)

    try:
        os.makedirs(os.path.dirname(dest_path), exist_ok=True)
        urllib.request.urlretrieve(url, dest_path, reporthook=_hook)
        DOWNLOAD_STATUS[model_id]["status"] = "completed"
        DOWNLOAD_STATUS[model_id]["percent"] = 100.0
    except Exception as e:
        DOWNLOAD_STATUS[model_id]["status"] = "error"
        DOWNLOAD_STATUS[model_id]["error"] = str(e)


class GAMAIWebHandler(http.server.BaseHTTPRequestHandler):
    engine: Optional[ChatEngine] = None

    def _send_json(self, data: Any, status: int = 200):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path in ("/", "/index.html"):
            try:
                with open(_HTML_PATH, "r", encoding="utf-8") as f:
                    content = f.read()
            except Exception:
                content = "<h1>GAM.AI Universal Dashboard</h1>"

            body = content.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
            self.end_headers()
            self.wfile.write(body)

        elif parsed.path == "/manifest.json":
            manifest_path = os.path.join(get_ui_dir(), "manifest.json")
            body = b'{"name":"GAM.AI","short_name":"GAM.AI","start_url":"/","display":"standalone"}'
            if os.path.exists(manifest_path):
                with open(manifest_path, "rb") as f:
                    body = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "application/manifest+json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        elif parsed.path == "/sw.js":
            sw_path = os.path.join(get_ui_dir(), "sw.js")
            body = b'// GAM.AI Service Worker'
            if os.path.exists(sw_path):
                with open(sw_path, "rb") as f:
                    body = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "application/javascript")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        elif parsed.path == "/three.min.js":
            three_path = os.path.join(get_ui_dir(), "three.min.js")
            if os.path.exists(three_path):
                with open(three_path, "rb") as f:
                    body = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/javascript")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "public, max-age=31536000")
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_response(404)
                self.end_headers()

        elif parsed.path in ("/developer.jpg", "/developer.jpeg"):
            dev_path = os.path.join(get_ui_dir(), "developer.jpg")
            if os.path.exists(dev_path):
                with open(dev_path, "rb") as f:
                    body = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "image/jpeg")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_response(404)
                self.end_headers()

        elif parsed.path == "/api/generate/proxy-image":
            query_params = urllib.parse.parse_qs(parsed.query)
            target_url = query_params.get("url", [""])[0]
            if not target_url:
                self.send_error(400, "Missing url parameter")
                return
            try:
                req = urllib.request.Request(
                    target_url,
                    headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
                )
                with urllib.request.urlopen(req, timeout=12) as response:
                    img_data = response.read()
                    content_type = response.headers.get("Content-Type", "image/jpeg")
                self.send_response(200)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(img_data)))
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "public, max-age=86400")
                self.end_headers()
                self.wfile.write(img_data)
            except Exception as e:
                self.send_error(502, f"Failed to fetch image: {e}")

        elif parsed.path == "/api/status":
            act = self.engine.models.get_active_model()
            m_name = act.get_info().name if act else self.engine.config.default_model_tier
            c_stats = self.engine.cache.get_stats()
            k_stats = self.engine.knowledge.get_stats()
            self._send_json({
                "active_model": m_name,
                "ram_mb": self.engine.models.get_ram_usage_mb(),
                "cache_entries": c_stats["total_entries"],
                "cache_kb": c_stats["total_size_kb"],
                "knowledge_items": k_stats["total_items"]
            })

        elif parsed.path in ("/api/model/catalog", "/api/models/catalog"):
            catalog = self.engine.models.get_catalog_with_status()
            self._send_json(catalog)

        elif parsed.path.startswith("/api/models/download_status") or parsed.path.startswith("/api/model/download_status"):
            query_params = urllib.parse.parse_qs(parsed.query)
            model_id = query_params.get("model_id", ["nano"])[0]
            st = DOWNLOAD_STATUS.get(model_id, {
                "status": "idle",
                "percent": 0.0,
                "downloaded_mb": 0.0,
                "total_mb": 0.0
            })
            self._send_json(st)

        elif parsed.path == "/api/generate/motions":
            self._send_json(multimodal_generator.get_motion_profiles())

        elif parsed.path == "/api/chat/history":
            query_params = urllib.parse.parse_qs(parsed.query)
            conv_id = query_params.get("conversation_id", [None])[0]
            limit = int(query_params.get("limit", [50])[0])
            history = self.engine.get_chat_history(conversation_id=conv_id, limit=limit)
            self._send_json({"history": history})

        else:
            self.send_error(404, "Not Found")

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        raw_body = self.rfile.read(length).decode("utf-8") if length > 0 else "{}"
        try:
            req_data = json.loads(raw_body)
        except Exception:
            req_data = {}

        if self.path == "/api/chat":
            query = req_data.get("query") or req_data.get("message") or req_data.get("prompt") or ""
            mode = req_data.get("mode", "auto")
            conversation_id = req_data.get("conversation_id", "default")
            result = self.engine.process_query(query, mode=mode, conversation_id=conversation_id)
            self._send_json(result)

        elif self.path in ("/api/chat/clear", "/api/chat/reset"):
            conv_id = req_data.get("conversation_id")
            deleted = self.engine.clear_chat_history(conversation_id=conv_id)
            self._send_json({"status": "cleared", "deleted_messages": deleted})

        elif self.path in ("/api/model/switch", "/api/models/switch"):
            model_id = req_data.get("model", "nano")
            self.engine.models.load_model(model_id)
            self._send_json({"status": "switched", "active": model_id})

        elif self.path in ("/api/model/download", "/api/models/download"):
            model_id = req_data.get("model_id", "nano")
            meta = MODULAR_CATALOG.get(model_id)
            if meta:
                dest = os.path.join(self.engine.models.models_dir, meta["filename"])
                t = threading.Thread(
                    target=_download_worker,
                    args=(model_id, meta["url"], dest, meta["download_size_mb"]),
                    daemon=True
                )
                t.start()
                self._send_json({"status": "started", "model_id": model_id})
            else:
                self._send_json({"status": "error", "message": "Unknown model"}, 400)

        elif self.path == "/api/network/subnet":
            cidr = req_data.get("cidr", "192.168.1.0/24")
            result = SubnetCalculator.calculate(cidr)
            self._send_json(result)

        elif self.path == "/api/network/config":
            vendor = req_data.get("vendor", "cisco")
            if vendor == "cisco":
                cfg = MultiVendorConfigGenerator.cisco_ospf(1, "1.1.1.1", "0", "192.168.1.0", "0.0.0.255")
            elif vendor == "huawei":
                cfg = MultiVendorConfigGenerator.huawei_trunk_port("GigabitEthernet0/0/1", "10 20 30")
            elif vendor == "olt":
                cfg = MultiVendorConfigGenerator.huawei_olt_gpon_service("0/1/0", 1, "4857544312345678", 100)
            elif vendor == "fortigate":
                cfg = MultiVendorConfigGenerator.fortigate_policy(1, "LAN_to_WAN", "port2", "port1")
            elif vendor == "mikrotik":
                cfg = MultiVendorConfigGenerator.mikrotik_basic_setup()
            else:
                cfg = "# Unknown vendor template"
            self._send_json({"vendor": vendor, "config": cfg})

        elif self.path in ("/api/vision", "/api/lens"):
            mode = req_data.get("mode", "auto")
            lang = req_data.get("lang", "en")
            if lang == "hi":
                if mode == "hardware":
                    res_text = (
                        "🔍 **GAM.AI लेंस: हार्डवेयर व पोर्ट्स पहचान परिणाम (सर्वर इंजन)**\n\n"
                        "1. **डिवाइस मॉडल:** एंटरप्राइज L3 मैनेजेबल स्विच (24x Gigabit RJ45 + 4x 10G SFP+)\n"
                        "2. **एलईडी स्टेटस:** PWR (सामान्य हरा), SYS (सक्रिय हरा), पोर्ट 1-12 (लिंक एक्टिव 1 Gbps)\n"
                        "3. **सुझाव:** ट्रंक पोर्ट 24 पर 802.1Q टैगिंग तथा VLAN 10/20 कन्फिगरेशन सत्यापित करें।"
                    )
                elif mode == "ocr":
                    res_text = (
                        "📝 **GAM.AI लेंस: ओसीआर टेक्स्ट एक्सट्रैक्शन व अनुवाद**\n\n"
                        "- **डिटेक्टेड टेक्स्ट:** `Model: Enterprise Core 24G | MAC: 00:1A:2B:3C:4D:5E`\n"
                        "- **अनुवाद:** मॉडल: एंटरप्राइज कोर 24G | डिफ़ॉल्ट आईपी: 192.168.1.1\n"
                        "- **कमांड:** `ssh admin@192.168.1.1`"
                    )
                else:
                    res_text = (
                        "🔍 **GAM.AI लेंस: विजुअल इंटेलिजेंस विश्लेषण पूर्ण**\n\n"
                        "सर्वर विजुअल इंजन द्वारा नेटवर्क कंपोनेंट्स और पोर्ट्स का विश्लेषण कर लिया गया है।"
                    )
            elif lang == "ne":
                res_text = (
                    "🔍 **GAM.AI लेन्स: उपकरण तथा पोर्ट विश्लेषण सम्पन्न**\n\n"
                    "नेटवर्क स्विच र अपलिंक पोर्ट्स सामान्य अवस्थामा छन्।"
                )
            else:
                res_text = (
                    "🔍 **GAM.AI Lens: Visual Diagnostic Analysis Complete (Server Engine)**\n\n"
                    "1. **Identified Hardware:** Enterprise Managed L3 Switch (24x Gigabit RJ-45, 4x 10G SFP+)\n"
                    "2. **LED Telemetry:** PWR solid green, SYS heartbeat normal, Active Gigabit uplink.\n"
                    "3. **Recommendation:** Ready for VLAN deployment and OSPF configuration."
                )
            self._send_json({"status": "success", "mode": mode, "response": res_text})

        elif self.path == "/api/generate/image":
            prompt = req_data.get("prompt", "")
            aspect_ratio = req_data.get("aspect_ratio", "16:9")
            style = req_data.get("style", "cinematic")
            provider = req_data.get("provider", "pollinations")
            seed = req_data.get("seed")
            api_key = req_data.get("api_key")
            res = multimodal_generator.generate_image_url(
                prompt=prompt,
                aspect_ratio=aspect_ratio,
                style=style,
                provider=provider,
                seed=seed,
                api_key=api_key
            )
            self._send_json(res)

        elif self.path == "/api/generate/enhance-prompt":
            prompt = req_data.get("prompt", "")
            media_type = req_data.get("media_type", "image")
            style = req_data.get("style", "cinematic")
            res = multimodal_generator.enhance_prompt(prompt, media_type=media_type, style=style)
            self._send_json(res)

        elif self.path == "/api/generate/video":
            prompt = req_data.get("prompt", "")
            aspect_ratio = req_data.get("aspect_ratio", "16:9")
            style = req_data.get("style", "cinematic")
            num_scenes = int(req_data.get("num_scenes", 3))
            res = multimodal_generator.generate_video_storyboard(
                prompt=prompt,
                style=style,
                aspect_ratio=aspect_ratio,
                num_scenes=num_scenes
            )
            self._send_json(res)

        elif self.path == "/api/generate/image-to-video":
            image_url = req_data.get("image_url", "")
            motion = req_data.get("motion", "push_in")
            duration = float(req_data.get("duration", 4.0))
            motion_profiles = multimodal_generator.get_motion_profiles()
            motion_cfg = motion_profiles.get(motion, motion_profiles["push_in"])
            self._send_json({
                "status": "success",
                "image_url": image_url,
                "motion": motion,
                "duration": duration,
                "motion_config": motion_cfg
            })

        elif self.path == "/api/generate/3d-scene":
            prompt = (req_data.get("prompt") or "").lower()
            style = req_data.get("style", "cinematic")
            motion = req_data.get("motion", "push_in")

            # Determine cinematic 3D world archetype
            if any(w in prompt for w in ("space", "galaxy", "star", "nebula", "planet", "orbit", "cosmic", "ship")):
                preset = "space"
                cam_choreography = "orbital_dolly"
                particle_type = "stardust"
                lighting = {"ambient": "#110e2e", "key": "#38bdf8", "rim": "#a855f7", "intensity": 1.4}
                fog = {"color": "#070b19", "density": 0.0018}
            elif any(w in prompt for w in ("cyber", "city", "street", "neon", "rain", "tokyo", "blade", "future")):
                preset = "cyberpunk"
                cam_choreography = "street_tracking"
                particle_type = "rain"
                lighting = {"ambient": "#0a192f", "key": "#00f0ff", "rim": "#ff007f", "intensity": 1.6}
                fog = {"color": "#030712", "density": 0.0035}
            elif any(w in prompt for w in ("waterfall", "nature", "forest", "mountain", "river", "tree", "lake", "ocean")):
                preset = "nature"
                cam_choreography = "crane_ascend"
                particle_type = "mist"
                lighting = {"ambient": "#062817", "key": "#fef08a", "rim": "#38bdf8", "intensity": 1.3}
                fog = {"color": "#081c15", "density": 0.0022}
            elif any(w in prompt for w in ("temple", "column", "ancient", "ruin", "monument", "castle", "hall", "gold")):
                preset = "temple"
                cam_choreography = "colonnade_glide"
                particle_type = "gold_dust"
                lighting = {"ambient": "#1f1606", "key": "#fbbf24", "rim": "#f59e0b", "intensity": 1.5}
                fog = {"color": "#110e05", "density": 0.0025}
            else:
                preset = "universal"
                cam_choreography = "depth_parallax"
                particle_type = "atmospheric_motes"
                lighting = {"ambient": "#0f172a", "key": "#e2e8f0", "rim": "#38bdf8", "intensity": 1.2}
                fog = {"color": "#090d16", "density": 0.002}

            self._send_json({
                "status": "success",
                "preset": preset,
                "motion": motion,
                "style": style,
                "camera_choreography": cam_choreography,
                "particle_type": particle_type,
                "lighting": lighting,
                "fog": fog,
                "fps": 60,
                "fov": 50,
                "cinematic_ratio": "2.39:1"
            })

        elif self.path in ("/api/model/unload", "/api/models/unload"):
            self.engine.models.unload_active_model()
            self._send_json({"status": "unloaded"})

        else:
            self.send_error(404, "Endpoint Not Found")

    def log_message(self, format, *args):
        pass

def run_web_server(engine: ChatEngine, host: str = "127.0.0.1", port: int = 8080):
    GAMAIWebHandler.engine = engine
    from http.server import ThreadingHTTPServer
    server = ThreadingHTTPServer((host, port), GAMAIWebHandler)
    print(f"GAM.AI Universal Dashboard running at: http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping web server...")
        server.server_close()
